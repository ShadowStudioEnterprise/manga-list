> Estado vigente 25/10/2026: PASS del último caso de actualización pública. La matriz conserva pruebas de distintas revisiones y sus límites; no certifica todas las funciones de 0bb93e7. Véase el informe de cierre.

# ML-16 — Estado consolidado

**Cobertura local, OAuth demo remoto y arranque offline de producción completados; queda sin ejecutar el cambio entre dos releases públicas distintas.** Este documento es la matriz vigente. `INFORME.md` conserva el historial de intentos y sus bloqueos, algunos ya superados. La prueba de arranque offline de la app instalada combina acción/observación del usuario con registro de conectividad y proceso; no se presenta como captura automatizada durante el corte.

Fecha: **24/10/2026**, Europe/Madrid. Safari nativo **18.6 (20621.3.11.11.3)**, macOS **15.7.9 (24G830)**. Pruebas por interfaz nativa/Web Inspector, sin Playwright WebKit. El corte físico fue realizado por el usuario, con registro automático local. Metadatos en `environment.json`.

Web pública: https://mangalist-61bb8.web.app. Laboratorio: proyecto `demo-mangalist`, candidato **6712945f9c0afa26ec6082e3b112b4fbf4c14211** del repositorio https://github.com/ShadowStudioEnterprise/manga-list. No se ha demostrado correspondencia entre ese candidato, main actual y los assets publicados. No se heredan resultados entre ellos.

| Caso | Estado vigente | Alcance y evidencia principal |
|---|---|---|
| Entorno y Safari real | PASS | Arranque y versión del navegador instalado; `environment.json`. |
| Apertura y navegación pública | PASS | Login y recuperación sin enviar formularios; `01-apertura.png`, historial. |
| Red pública | PASS limitado | Carga y recarga observadas, recursos mediante SW; `04-red.txt/png`. Sin auditoría completa de tráfico ni backend autenticado. |
| Consola pública | PASS limitado | Sin errores visibles en la observación de recarga del login; `05-consola-recarga.txt`. No acredita todos los estados. |
| Responsive | PASS limitado | Login público a 320, 768 y 1280 px en modo responsive de Safari; capturas `06`, `07`, `20`. Sin dispositivo iOS ni cobertura completa de pantallas autenticadas. |
| Autenticación y creación demo | PASS | Nueva identidad sintética en Auth emulado, creación y salida; `09-demo-creada.txt`, `24-demo-logout.txt`. |
| Sincronización entre pestañas | PASS | Capítulo 16→17 e importación recibidos en otra pestaña; `19-tabs-sincronizacion.txt/png`. No mide exclusión de listeners. |
| Exportar/importar JSON | PASS | Descarga real con procedencia de servidor, previsualización e importación de obra nueva; `export-demo.json`, `17`, `18`. |
| Exportar sin confirmación | PASS | Descarga rechazada con transporte desconectado; `14-export-offline-rechazado.txt`. |
| Escritura offline y recuperación | PASS | Favorito pendiente conservado, aviso de plazo, recuperación tras restaurar servicios/SDK y Reintentar. Servidor antes false/después true, capítulo 17; `32`, `33`, `35`, `37`, `39`. No es ensayo ininterrumpido de duración ni reconexión automática. |
| Instalación y reapertura PWA | PASS | App independiente «MangaList ML16 Validación», login sin sesión; `21`, `22`, `23`. |
| Shell con origen local caído | PASS | Login/recuperación desde caché, conexiones al origen rechazadas; `26`, `27`. |
| Actualización local de worker | PASS | Dos pestañas, activo 1/esperando 2, formulario conservado; al cerrar clientes se activa 2; `28`–`31`. Marcador de prueba, sin cambiar assets de aplicación. |
| Recarga con corte físico guiado | PASS | Usuario desconecta red; dos arranques con online=false, controlador activo y recuperación/login renderizados; reconexión posterior. `44-recarga-fisica-registro.json`, `45-recarga-fisica-evaluacion.json`. Build demo instrumentado en 9536, no app instalada de producción. |
| Consola del laboratorio Vite | FAIL local | WebSocket/HMR desactivado produce errores `ws.send`. Incidencia abierta del laboratorio; no defecto de producción demostrado. |
| OAuth Google y cuenta demo remota | PASS | Usuario autoriza y completa acceso Google en la app instalada. Retorno a biblioteca vacía confirmada por servidor y salida al terminar; `47` y `54`. Sin escrituras de obras. |
| Consulta de actualización publicada | PASS | App instalada cachea revisión `9006459`, misma publicada. `registration.update()` termina con activo activated, waiting/installing null; `46`, `48`. |
| Cambio entre releases publicadas | PASS, actualizado 25/10/2026 | Publicación autorizada 0c871ab → 0bb93e7, dos pestañas controladas, aviso/texto conservados, waiting hasta salir del último cliente y nueva versión al reabrir. CIERRE-ACTUALIZACION-PUBLICA.md y fix-publication-evidence. |
| App instalada de producción arrancando sin red | PASS guiado | Proceso nuevo arranca a 17:11:23 dentro de intervalo offline 17:11:15–17:11:58. Usuario observa «Biblioteca o aviso de datos locales». Tras reconectar, app muestra biblioteca demo vacía y confirmación del servidor; `50`–`53`. No hay captura automática del renderizado durante el corte. |

## Incidencias del entorno y límites

- **LAB-01:** errores de Vite al abrir el cliente dev con `MANGALIST_E2E_NO_HMR=true`; reproducción y detalle en el historial. La web pública no usa ese servidor dev.
- **LAB-02:** procesos locales Auth/web se detuvieron entre intervenciones; causa no determinada. Se restauró solo la identidad sintética con el mismo UID en el emulador y se recuperó la escritura original. No se vació Firestore.
- **LAB-03:** el build PWA demo con clave ficticia produjo `API_KEY_INVALID` al inicializar Identity Toolkit. No hubo login ni escritura remota desde ese build.
- Disco escaso y avisos de iCloud en el selector; los ensayos de importación terminaron. No se borraron archivos personales.
- El build PWA registra `dirty:true` por soporte generado automáticamente por Quasar/pnpm. Es material de ensayo, no artefacto de release reproducido con el lockfile npm.
- Algunos `.txt` iniciales son diffs o ausencia de cambios; deben leerse junto con las capturas y el historial, no como instantáneas completas aisladas.

## Evidencias y cambios

El paquete de entrega excluye `fixture-private.json`, logs de servicio y archivos de soporte de instalación. Incluye evidencias numeradas, exportación sintética, metadatos, guías e instrumentación. `SHA256SUMS` dentro del paquete cubre exactamente sus archivos. El informe completo original permanece en la carpeta de trabajo.

No se modificaron fuentes rastreadas del candidato (`git status --short` vacío al consolidar), producción, datos personales, reglas remotas, IAM, facturación ni plan Spark. No hubo deploy, merge ni publicación de evidencias. Los auxiliares y builds son locales; quedó instalada la app de validación mencionada y dos obras sintéticas en el emulador.

El estado puede cerrarse como **ensayo de Safari nativo con cobertura local y de producción expresamente descrita**. Incluye OAuth real de cuenta demo, salida, consulta de versión y arranque frío offline guiado de la app instalada. El cambio entre dos releases públicas sigue BLOCKED porque la revisión instalada y publicada coincide y no existe una segunda versión controlada disponible para el ensayo. No se ha autorizado ni realizado despliegue para provocarlo. La app queda instalada y sin sesión de MangaList iniciada; no se ha borrado la cuenta demo ni revocado la sesión Google.

Recomprobado a las **17:17:21 Europe/Madrid**: continúa publicada la revisión `9006459`; no hay avance del estado de ese último caso (`55-public-recheck-result.json`). Secuencia concreta preparada en `ULTIMO-CASO-PENDIENTE.md`. Esta recomprobación es una lectura pública, no una nueva ejecución del ciclo de actualización.

Por encargo posterior del usuario se preparó, sin desplegar, la candidata **ace8311** sobre main `7f5ff099`, con patch, bundle Git, build PWA e inventario limpio. La propuesta de revisión está en `../ML16-release-review/RELEASE-PROPOSAL.md`. No cambia el estado del último ensayo: requiere una publicación separada y aprobada, y la candidata aún tiene condiciones operativas pendientes.


## Estado posterior: publicación autorizada

El 24/10/2026 el usuario autorizó y se publicó 0c871ab exclusivamente en hosting:app, a las 23:04:26 Europe/Madrid. El hook original gcloud pasó y las reglas efectivas permanecieron sin cambios. El estado histórico de preparación anterior queda superado por PUBLICACION-Y-VALIDACION.md. Hay PASS de detección waiting, texto conservado y apertura posterior de versión nueva; FAIL observado de aviso visual y BLOCKED del ensayo estricto con dos clientes controlados (la primera pestaña tenía controller:null). No hay PASS global de ML-16 ni fusión de PR.


Actualización del seguimiento: la revisión local **0bb93e755d76fc5cd92f54978e732c5924ba27e7** corrige el aviso en pestañas sin controller y evita avisos falsos durante instalación inicial. PASS local en Safari nativo: dos clientes controlados, waiting al cerrar uno y activación al salir del último; también aviso en cliente sin controlar. 119 unitarias, 4 PWA y builds/inventarios aprobados. No publicada, sin CI remoto de esta revisión. Producción sigue en 0c871ab y el requisito estricto entre releases públicas continúa pendiente. Detalle en ../ML16-release-review/SEGUIMIENTO-AVISO-PWA.md.


## Actualización vigente — 25/10/2026

Publicada con autorización la revisión **0bb93e755d76fc5cd92f54978e732c5924ba27e7**, únicamente en hosting:app, a las 00:19 Europe/Madrid. **PASS del caso pendiente entre releases públicas en Safari real**: ambas pestañas controladas antes de publicar, worker anterior retenido y nuevo waiting, aviso visible y texto conservado; cerrar una mantiene waiting, cerrar la última y reabrir carga la nueva revisión. Spark y reglas comprobados, sin cambios de reglas ni merge. El estado histórico BLOCKED de ese caso queda superado. No equivale a una revalidación integral de todas las funciones en 0bb93e7; CI remoto y flujos autenticados/offline de esta revisión no se repitieron. Informe vigente: ../ML16-release-review/CIERRE-ACTUALIZACION-PUBLICA.md.
