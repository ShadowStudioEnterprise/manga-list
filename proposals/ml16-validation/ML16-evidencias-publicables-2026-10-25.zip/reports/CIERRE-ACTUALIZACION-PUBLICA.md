# ML-16 — actualización pública en Safari nativo

**PASS del ensayo pendiente entre dos releases públicas.** Publicación autorizada el **25/10/2026 a las 00:19:00 Europe/Madrid**, de `0c871abbc25fffa3930390ffc8b64204ae473f82` a **0bb93e755d76fc5cd92f54978e732c5924ba27e7**. Las evidencias JSON conservan UTC: el 24/10 a las 22:19 UTC corresponde al 25/10 a las 00:19 en Madrid.

Se aplicó el «sí» del titular a la candidata concreta presentada y al alcance **hosting:app de mangalist-61bb8**. Sin merge, despliegue del portal, reglas, datos, Auth, IAM ni facturación. La PR #22 sigue correspondiendo a 0c871ab y no se fusionó; el seguimiento 0bb93e7 se conserva en rama local, patch y bundle.

## Publicación verificable

- Safari **18.6 (20621.3.11.11.3)**, macOS **15.7.9 (24G830)**. Leído del Mac en esta ejecución: fix-publication-evidence/environment.json. Safari real, no Playwright WebKit.
- Release nueva: `sites/mangalist-61bb8/releases/1792880340658000`.
- Versión Hosting nueva: `sites/mangalist-61bb8/versions/df7ace55fe1a68a4`; anterior: `9c1b993391792d8f`.
- Build realmente publicado: `builtAt:2026-10-24T22:18:36.124Z`, revisión 0bb93e7, PWA, proyecto mangalist-61bb8, dirty:false.
- Inventario SHA-256: **9686c29947cb45a2f38062a5d8ebd64597ae3749d198218d14fdbb5c9eb0e319**.
- Worker SHA-256: **2b884eabac0b566c5b79287109a47c7d00591a6c30bfabe58a47ad618587cb88**.
- build-info.json, build-evidence.json y sw.js servidos por HTTPS, HTTP 200, con hashes iguales a los archivos generados por el hook del despliegue. No se confunden con el build anterior de revisión.

## Resultado por prueba

| Prueba | Estado | Evidencia / alcance |
|---|---|---|
| Hook original Spark remoto antes de publicar | PASS | prepublish-original-spark-hook.log: billing desactivado/sin cuenta y Firestore Standard, sin modificar el comprobador |
| Reglas efectivas comparadas antes y después | PASS | prepublish-readonly.json y published-verification.json: bytes iguales antes; mismo ruleset y updateTime después |
| Build y check:release del despliegue | PASS | authorized-hosting-deploy.log; árbol limpio, proyecto y revisión correctos |
| Publicación y cotejo de archivos públicos | PASS | publication-record.json y published-verification.json |
| Primera pestaña controlada antes de publicar | PASS | 00:17:37, controller true, activo activated, waiting null; index-o9IVf4oq.js de la publicación anterior. first-before.txt |
| Segunda pestaña controlada antes de publicar | PASS | 00:18:09, controller true, mismo recurso antiguo. second-before.txt |
| Formulario sintético preparado sin envío | PASS | form-before.txt: [CUENTA-OMITIDA]; no se envió login ni recuperación |
| Worker nuevo esperando con dos clientes | PASS | 00:19:16: activo conserva la misma identidad, nuevo worker distinto waiting installed, controllerChanges:0. two-waiting.txt/png |
| Aviso visible y formulario conservado | PASS | En el mismo estado: notice:true y texto idéntico, corroborados por árbol AX y captura |
| Cerrar solo una pestaña | PASS | 00:19:29: activo anterior sigue siendo el mismo, waiting installed, controllerChanges:0, aviso y texto presentes. one-waiting.txt/png |
| Salir del último cliente de Safari | PASS | last-client-closed.json, 00:19:50: desaparece la página del origen; se cerró el cliente tras guardar evidencia del texto sintético |
| Reabrir con la nueva publicación | PASS | 00:20:20: controller true, activo activated, waiting null, notice:false, revisión 0bb93e7 y recurso nuevo index-DbW9oJvo.js. reopened.txt/png |
| Consola del recorrido observado | PASS limitado | Las instantáneas muestran evaluaciones y estados sin nuevos errores visibles; no es auditoría exhaustiva de consola ni backend |
| Red / recursos de esta reapertura | PASS limitado | Cotejo HTTPS de tres archivos y recurso JS nuevo identificado en Safari; no se capturó todo el tráfico ni se auditó red autenticada |
| Spark remoto posterior | PASS | 00:20:42 Europe/Madrid: billingEnabled:false, sin cuenta vinculada, Firestore Native Standard eur3. spark-remote-readonly.json; sin documentos de bibliotecas |
| Rama sin controlador de la corrección | PASS local; aceptación pública futura pendiente | Reproducida antes del fix y aprobada después en Safari nativo demo y Chromium. Este cambio público lo recorren clientes antiguos 0c871ab controlados: no prueba automáticamente cómo 0bb93e7 anunciará otra actualización futura en un cliente sin controller |
| CI remoto de 0bb93e7 | BLOCKED / no ejecutado | Se informó antes de autorizar. No se heredan las ejecuciones CI de 0c871ab. Hay 119 unitarias, 4 PWA, lint, Spark local, documentación, build e inventario locales aprobados de la corrección |
| OAuth / import-export / offline / responsive de 0bb93e7 | BLOCKED / no repetidos aquí | Sus evidencias anteriores mantienen sus versiones, cuentas demo y límites. Este ensayo no las vuelve a ejecutar ni las convierte en cobertura integral de 0bb93e7 |

La actualización fue pasiva: no se envió SKIP_WAITING, no se recargó automáticamente por controllerchange, no se borraron caches ni datos y no se forzó un rollback. El marcador ml16OldActive se guardó en memoria de la página para comparar identidad; no se instrumentó el worker de producción. Las pruebas de dos pestañas usan Safari normal; la app instalada tiene su propio contexto y no se atribuye a ella esta inspección.

## Estado de incidencias y límites de cierre

- **SETUP-01 resuelto:** se comprobó controller en ambas pestañas antes de publicar. El anterior bloqueo del caso estricto por preparación incompleta queda superado por esta ejecución pública.
- **SAFARI-UPDATE-01:** el aviso aparece en este recorrido público controlado. El defecto sin controller se reprodujo y corrigió localmente, y su corrección se publicó; su aceptación pública en una siguiente actualización todavía no existe y no se inventa.
- **DOC-01 corregido en fuente 0bb93e7:** la guía declara 5001 e importación recuperable v1. No se desplegó el portal docs.
- Los incidentes históricos de Vite/CSP y fallos preparatorios siguen perteneciendo al laboratorio y se conservan en sus informes. No se declaran defectos de producción por esos logs.

Se puede cerrar **el ensayo pendiente de actualización entre releases públicas como PASS**. Esto no es un PASS global de todas las funciones sobre la última revisión: el conjunto ML-16 conserva la matriz histórica de versiones y las limitaciones expresas anteriores. No hay otra publicación, fusión ni modificación de Firebase autorizada implícitamente por este cierre.


Estado posterior: CI y cobertura nativa ampliados el 25/10/2026. Véase AMPLIACION-CI-Y-SAFARI.md para el resultado vigente, distinguiendo SHA publicado, árbol equivalente y entorno de emuladores.
