# ML-16 — OAuth remoto y arranque offline instalado

25/10/2026, Europe/Madrid. Safari real **18.6 (20621.3.11.11.3)** sobre macOS **15.7.9 (24G830)**. App instalada «MangaList ML16 Validación», producción https://mangalist-61bb8.web.app. Revisión **0bb93e755d76fc5cd92f54978e732c5924ba27e7**, comprobada en el inspector nativo de la app antes del ensayo (worker activo, controller presente y sin waiting; index-DbW9oJvo.js).

| Prueba | Resultado | Evidencia y alcance |
|---|---|---|
| OAuth Google remoto | PASS | Google reutilizó una sesión existente; el usuario confirmó expresamente que era la cuenta demo autorizada. Retorno a biblioteca vacía con instantánea del servidor. oauth-demo-current.txt/png |
| Arranque frío offline instalado | PASS guiado | App sin proceso desde 01:54:44, desconexión 01:57:43, proceso nuevo PID 53754 a las 01:58:12. Sondas públicas fallan ENOTFOUND tanto al corte como al arranque. El usuario informó «Biblioteca o aviso de datos locales». offline-key-events.json y registro completo |
| Reconexión conservando app | PASS | A las 02:54:22 CEST (antes del cambio de hora), online y HEAD público 200. Mismo PID 53754. Biblioteca vacía con mensaje de última instantánea del servidor sin pendientes. after-reconnect.txt/png |
| Captura automática durante offline | BLOCKED | La ventana de captura venció antes de que se realizara el corte. No hay captura automática de la pantalla sin red. capture-window-timeout.json |
| Salida de la demo | PASS | Se cerró sesión y se verificó /login. signed-out.txt/png |

Las horas anteriores son Europe/Madrid; los JSON conservan UTC. El intervalo registrado sin red es de unos 56 min 39 s. El inicio frío se acredita con ausencia previa del proceso y aparición de un PID nuevo durante ese intervalo. La representación de la pantalla offline es observación del usuario, no inspección automática. La biblioteca demo está vacía: esto no valida visualización offline de obras preexistentes ni escrituras pendientes en producción. OAuth usó SSO ya autorizado; no se prueba introducir credenciales, MFA o recuperación. No se afirma consola o red sin errores durante un intervalo que no se capturó con el inspector. ENOTFOUND es el fallo esperado de la sonda durante el corte.

No se añadieron ni importaron obras en Firebase remoto, ni se modificaron reglas, IAM o facturación. No hubo otro despliegue ni merge. El observador solo usó loopback y sondas HEAD públicas; al cierre ya no había listener en 9589. Se conserva el registro bruto y un extracto de eventos sin los heartbeats. No se incluyen credenciales ni identificadores de cuenta en este informe.

Esta ampliación sustituye únicamente el estado «no repetidos» de OAuth remoto y arranque físico offline sobre 0bb93e7 en AMPLIACION-CI-Y-SAFARI.md. Las pruebas de actualización publicada, CI, import/export, responsive y múltiples pestañas mantienen el alcance y las evidencias de los informes anteriores. PR #23 continúa preparada para revisión; este ensayo no autoriza su fusión.
