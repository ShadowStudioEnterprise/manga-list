# ML-16 — publicación autorizada y validación posterior

Fecha: **24/10/2026**, Europe/Madrid. Navegador real: **Safari 18.6 (20621.3.11.11.3)**; macOS **15.7.9 (24G830)**, entorno previamente identificado y corroborado en el menú Desarrollo. No es Playwright WebKit.

El usuario respondió «autorizo» tras recibir la candidata exacta y el alcance pendiente de publicación. Se publicó exclusivamente **hosting:app** del proyecto/sitio **mangalist-61bb8**, desde **0c871abbc25fffa3930390ffc8b64204ae473f82**, árbol limpio. No hubo merge, publicación del portal, modificación de reglas, datos, Auth, IAM ni facturación. La PR #22 continúa en borrador.

Publicación confirmada por Firebase a las **23:04:26.789**. Release: `sites/mangalist-61bb8/releases/1792875866789000`. Versión Hosting: `sites/mangalist-61bb8/versions/9c1b993391792d8f`. La anterior era `3170cd3eeaae1ded`, revisión `9006459`.

## Resultados

| Prueba | Estado | Evidencia y límite |
|---|---|---|
| Hook original Spark antes y durante publicación | PASS | gcloud oficial 590.0.1 instalado localmente, archivo SHA-256 verificado; check:spark:remote sin modificar pasa. Token de la sesión Firebase usado solo en memoria del proceso. No se habilitaron APIs. |
| Reglas efectivas frente a candidata | PASS | Comparación exacta antes de publicar; ruleset y fecha de actualización idénticos después. prepublish-readonly.json y published-verification.json. |
| Compilación y check:release del despliegue | PASS | PWA reconstruida por el hook original, revisión exacta, dirty:false. authorized-hosting-deploy.log. |
| Publicación y recursos servidos | PASS | build-info.json, build-evidence.json y sw.js HTTP 200, SHA-256 iguales a los del build publicado. published-verification.json. |
| Safari antes de publicar | PASS | Segunda pestaña controlada por worker activo, revisión 9006459. safari-public-before.txt. |
| Detección de nueva release | PASS | registration.update() pasa por installing y waiting installed mientras el worker anterior sigue activo. safari-public-update.txt y safari-public-waiting.txt. |
| Formulario sintético conservado | PASS | [CUENTA-OMITIDA] permanece sin enviar durante installing/waiting y al cerrar la otra pestaña. Capturas y registros. No se envió recuperación de contraseña. |
| Aviso visual de actualización en cliente anterior | FAIL observado | No aparece el aviso con waiting instalado; DOM sin «Hay una nueva versión disponible». safari-public-waiting.png y safari-one-client.txt. Causa no aislada; no se atribuye automáticamente a la revisión nueva. |
| Espera con dos clientes controlados | BLOCKED por preparación incompleta | La pestaña del formulario resultó tener controller:null; solo la segunda estaba controlada. Tras cerrar esta, waiting desapareció. No demuestra activación prematura: el cliente restante no estaba controlado. Falta el ensayo con dos clientes controlados; no se repite un despliegue artificial para provocarlo. |
| Apertura posterior de Safari | PASS | Tras cerrar los clientes de ensayo y reabrir, login renderizado, controller sw.js, active activated, waiting null; recursos index-o9IVf4oq.js del build nuevo y revisión 0c871ab. Antes cargaba index-CnykS3lW.js. safari-public-after.txt/png. |
| App instalada posterior | PASS limitado | Reapertura de MangaList ML16 Validación muestra login. installed-after-publication.txt/png. No se inspeccionó su revisión interna ni se repitió aquí el corte físico de red. |
| Spark después de publicar | PASS | 23:05:55: billingEnabled:false, sin cuenta vinculada, Firestore Native Standard eur3. spark-remote-readonly.json. |
| OAuth, importación/exportación y offline de esta revisión | BLOCKED / no repetidos | Las pruebas anteriores pertenecen a sus versiones y entornos documentados; no se heredan automáticamente como cobertura de la candidata publicada. No se usaron bibliotecas personales. |

## Incidencias reproducibles y seguimiento

**SAFARI-UPDATE-01:** en la página de recuperación anterior, mantener texto sintético sin enviar, publicar una versión diferente, ejecutar registration.update() y observar waiting installed. En este recorrido el aviso visual no apareció. Conservar el estado y la captura antes de cerrar clientes. No se conoce aún si depende del cliente anterior, su estado no controlado o la lógica de aviso; no se declara corregido.

**SETUP-01:** una primera navegación puede quedar sin controller aunque exista una registration activa. Antes del próximo ensayo entre releases reales, comprobar controller en CADA cliente y registrar el valor antes de publicar. La segunda pestaña controlada sí se verificó en este ensayo; la primera no. Este límite impide dar PASS al requisito estricto de múltiples clientes.

**DOC-01:** la guía heredada de recuperación dice límite 1001 e identidad de importación v1; el contrato actual exige 5001 y recoverableImport:1. Ya documentado en la propuesta, sin ampliar la candidata publicada.

No se forzó skipWaiting, no se eliminaron cachés ni bibliotecas. El texto sintético no se envió y las pestañas que lo contenían se cerraron tras guardar evidencia. La app instalada queda en login.

## Artefacto realmente publicado

El hook reconstruyó el paquete: builtAt **2026-10-24T21:04:02.066Z**. El inventario real tiene SHA-256 **242aaa7e9da38c404c603b0feed4806b6fc54bf3ebead6c92f4d6fa91ac4f4b0**; worker **d98566e2b46666ed99eddf29029f3b0a14f3d853fd83b13a27f59830836a0a32**. Difieren del ZIP previo de revisión porque la fecha del build cambia. Se conserva aparte artifacts/pwa-published y un paquete de evidencia de publicación; el ZIP de revisión sigue siendo histórico.

El bloqueo por ausencia de segunda publicación queda resuelto. **ML-16 no obtiene PASS global**: hay una incidencia de aviso y el caso estricto con dos clientes controlados no está acreditado. Para ese ensayo debe aprovecharse una próxima release real aprobada, con preparación corregida.
