# Arranque frío offline de la app instalada

Preparado el 24/10/2026 tras OAuth demo. La app **MangaList ML16 Validación** está cerrada y tiene sesión demo con biblioteca vacía. Safari conserva una pestaña local de registro de conectividad en 9536: déjala abierta.

1. Desconecta Wi-Fi y cualquier otra conexión activa a Internet.
2. Abre **MangaList ML16 Validación** desde el Dock o Aplicaciones. Debe abrirse su ventana propia, no una pestaña de Safari.
3. Comprueba qué aparece: biblioteca vacía, login, aviso de datos locales o error/pantalla blanca. No añadas obras ni inicies otro OAuth sin red.
4. Reconecta Internet sin cerrar la app. Comunica en el chat **«app offline abierta»** y el texto/pantalla que viste, o el error exacto.

Si es posible, conserva una captura únicamente de esa ventana mientras está sin red; no es imprescindible para continuar, pero permite contrastar el resultado manual. No compartas contraseña, códigos ni bibliotecas personales.

El registro compañero y la hora de inicio del proceso sirven como apoyo temporal. La confirmación del renderizado offline será una observación del usuario, distinta de la lectura automatizada posterior a reconectar. No modifica la publicación, worker, caché ni datos remotos.
