# ML-16 — Reintento Safari nativo, 24/10/2026

**Estado final ampliado:** OAuth demo remoto y salida PASS; arranque frío offline de la app instalada de producción PASS guiado, con límites de observación manual documentados. Consulta de actualización PASS, pero transición entre dos releases públicas BLOCKED: instalada y publicada son la misma revisión `9006459`. No hubo deploy. Véase `ESTADO-ACTUAL.md` y el último apartado.

**Ampliación de producción desde las 17:04:** OAuth Google con cuenta demo autorizada pasa; la app vuelve a biblioteca vacía confirmada. Se comprueba actualización real: revisión cacheada y pública coinciden en `9006459`, sin worker nuevo pendiente. Arranque offline de la app instalada preparado para acción guiada del usuario. El detalle está al final y la matriz vigente en `ESTADO-ACTUAL.md`.

**Último resultado, 16:56 Europe/Madrid: PASS de recarga offline con corte de red realizado por el usuario.** Registro automático de Safari: dos arranques con `online:false`, service worker controlando y pantallas de recuperación/login renderizadas. Se verificó reconexión posterior. Este resultado sustituye el bloqueo histórico del corte físico para el shell demo local; no extiende la validación al backend remoto ni a la app instalada de producción. Véase el último apartado.

**Estado actualizado tras continuación hasta aproximadamente las 16:47 Europe/Madrid:** Safari real accesible; se añaden PASS de shell PWA con origen local caído, ciclo local de actualización con dos pestañas y escritura offline recuperada. El detalle actualizado está al final. Las filas BLOCKED del primer ensayo sobre PWA deben interpretarse con esa ampliación: el cambio entre workers se ha probado localmente, no mediante actualización de producción. Permanecen sin ejecutar el corte físico de red y OAuth/cuentas remotas. No se declara cierre exhaustivo de ML-16.

Ejecutado en el Mac del usuario aproximadamente 07:21–07:30, Europe/Madrid (UTC+02:00). **El acceso a Safari real funciona. ML-16 queda validado parcialmente, no cerrado por completo.** No se ha utilizado Playwright WebKit, simulador ni evidencia histórica como resultado de esta ejecución.

Safari **18.6 (20621.3.11.11.3)**; macOS **15.7.9 (24G830)**. Control mediante interfaz nativa y Web Inspector de Safari. Metadatos: `environment.json`. Disco: unos 2 GiB disponibles al inicio y 991 MiB en la medición de las 07:28. El entorno sí consiguió arrancar; no se reprodujo un bloqueo de Safari por espacio.

Objetivo público: https://mangalist-61bb8.web.app. Producción se abrió en ventana privada sin autenticación. Recursos observados: `index-CnykS3lW.js`, `firebase-BX5uX8oA.js`, `LoginPage-CIqI7hJC.js`; no se afirma que el código publicado coincida con el candidato local.

Laboratorio: http://127.0.0.1:9516, proyecto **demo-mangalist**, Auth 127.0.0.1:9199 y Firestore 127.0.0.1:8188. Candidato local `6712945f9c0afa26ec6082e3b112b4fbf4c14211`. Se recuperaron Auth y servidor web; se reutilizó el Firestore demo que ya estaba ejecutándose. Se creó una identidad sintética nueva y exclusivamente dos obras de esta prueba. No es una ejecución desde cero de la suite CI ni una comprobación de la revisión actual de main.

| Prueba | Estado | Resultado y alcance |
|---|---|---|
| Inicio del entorno y versión | PASS | Safari nativo operativo, Auth emulado y Quasar dev arrancados; `auth.log`, `app.log`, `environment.json`. |
| Apertura pública | PASS | HTTPS abre `#/login`, con correo, contraseña, Google y recuperación visibles. `01-apertura.png`. |
| Navegación pública | PASS | Login → recuperación → login. No se enviaron correos ni formularios a Auth remoto. |
| Consola pública | PASS | Sin errores visibles en la consola observada tras recargar; alcance limitado al login y navegación realizada. `05-consola-recarga.txt`. No certifica todos los estados. |
| Red pública | PASS | Inspector Red registra documento, JS, CSS y manifest; recursos servidos por service worker tras recarga. `04-red.txt`, `04-red.png`. No es una auditoría HAR completa ni una prueba de backend autenticado. |
| Responsive público | PASS | Login inspeccionado a 320×800, 768×800 y 1280×800 mediante modo responsive del Safari instalado. Capturas `06`, `07`, `20`; controles visibles y adaptación de columnas. No acredita iPhone físico, teclado móvil ni toda la app autenticada. |
| Acceso autenticado demo | PASS | Cuenta nueva del emulador, biblioteca vacía confirmada; crear «ML16 Safari Demo», capítulo 16, y guardar. |
| Múltiples pestañas demo | PASS | Segunda pestaña privada requirió acceso explícito con la misma identidad emulada. Incremento 16→17 y posterior importación visibles en la otra pestaña con confirmación de servidor. `19-tabs-sincronizacion.txt/png`. No se midió exclusión de listeners ni cierre de sesión compartido entre pestañas privadas. |
| Desconexión del SDK | PASS | `disableNetwork(db)` solo en una pestaña demo: aviso de datos locales sin confirmación. Exportar JSON devuelve «El servicio no está disponible temporalmente». `13` y `14`. |
| Reconexión del SDK por recarga | PASS | Recarga restaura transporte, conserva sesión y recupera la obra/confirmación del servidor; exportación posterior correcta. `15`, `16`, `export-demo.json`. No se probó reconexión automática ni cola de escrituras offline. |
| Exportar JSON | PASS | Descarga real de Safari de 624 bytes; `formatVersion:2`, `verification.source:server`, `hasPendingWrites:false`, una obra, capítulo 17. Se verificó solo el archivo identificado en Descargas como resultado de esta prueba. Copia en `export-demo.json`. CSV y copias divididas no ejecutados. |
| Importar JSON | PASS | Fixture derivado del JSON demo, nombre «ML16 Safari Importado», sin ID: previsualización 1 nueva/0 duplicados/0 errores, importación correcta y biblioteca final con 2 obras. `17-import-preview.txt`, `18-import-final.txt/png`, `import-demo.json`. |
| Cerrar sesión demo | PASS | Regresa a `#/login` en la pestaña elegida. `24-demo-logout.txt`. |
| PWA: instalación y reapertura | PASS | Añadir al Dock con nombre independiente **MangaList ML16 Validación**; abre ventana WebAppWindow en login. Cerrar proceso y reabrir vuelve al login. `21-pwa-dialogo.png`, `22-pwa-abierta.txt/png`, `23-pwa-reabierta.txt`. |
| Consola del laboratorio sin HMR | FAIL | WebSocket de Vite falla, seguido de `TypeError: undefined is not an object (evaluating 'ws.send')`. Incidencia de laboratorio descrita abajo; no atribuida a la web publicada. |
| Offline físico y PWA sin red | BLOCKED | No se aisló la conectividad de Safari/PWA a nivel de red. La desconexión SDK anterior no prueba navegación ni arranque offline del shell. No se alteró la red del Mac. |
| PWA: actualización entre versiones | BLOCKED | No hay una segunda versión controlada en este ensayo. No se desplegó para provocarla. Instalación/reapertura y recursos SW no equivalen a validar actualización. |
| OAuth y cuentas en producción | BLOCKED | No se proporcionó cuenta demo remota autorizada. Se cubrieron acceso, creación, exportación, importación y salida mediante emuladores; no OAuth Google real, correo real ni bibliotecas personales. |

## Incidencias y reproducción

**LAB-01 — Errores de Vite con HMR desactivado.** Arrancar Quasar dev del candidato con `MANGALIST_E2E_NO_HMR=true`, variables Firebase demo y puerto 9516; abrir con Safari 18.6 y abrir Desarrollo → Mostrar consola de JavaScript. Se observaron fallo de conexión a `ws://127.0.0.1:9516/`, `[vite] failed to connect to websocket` y errores `ws.send`, con contador de seis errores. Las operaciones de datos descritas sí completaron. No se investigó una corrección porque este encargo es validación. El archivo `12-demo-consola.txt` es un fragmento/diff: el detalle se observó en la salida del inspector durante esta ejecución.

**ENV-01 — Espacio escaso.** El selector nativo mostraba avisos de iCloud «No tienes suficiente espacio de almacenamiento para cargar este ítem», incluso para el fixture. Aun así seleccionó el archivo local y la importación terminó correctamente. No se declara fallo de MangaList por este aviso ni se borraron archivos del usuario.

**Instrumentación.** Un primer comando con `await import` en el nivel superior produjo `SyntaxError: Unexpected keyword 'import'` en la consola; se corrigió usando función async. Es un error del comando de prueba, no del producto. El helper local `capacity-results/ml16-controls.js` comprueba origen, proyecto demo y patrón de identidad antes de desactivar el transporte; no modifica el runtime publicado.

## Evidencias y límites

Los `.txt` iniciales 01–16 incluyen diferencias del árbol de accesibilidad, y algunos solo indican ausencia de cambios: no son instantáneas completas independientes. Las capturas PNG, el JSON descargado y las instantáneas completas 17–19 y 22–24 complementan el registro. Los resultados se basan también en las observaciones nativas de la sesión. No se presenta una captura parcial como prueba exhaustiva de red/consola.

No se actualizaron fuentes de la aplicación rastreadas por Git; `git status --short` del candidato terminó vacío. El auxiliar se creó bajo el directorio local ignorado `capacity-results`. No se modificó producción, Firebase remoto, reglas remotas, IAM, facturación ni planes; no hubo deploy, merge ni activación de Blaze. No se consultó ni modificó ninguna biblioteca personal. Los recursos públicos normales de la página sí se solicitaron al visitarla.

Queda instalada `[RUTA-LOCAL-OMITIDA] ML16 Validación.app`, sin sesión iniciada, y se conserva la descarga sintética en Descargas. Los servicios Auth y web creados para este ensayo permanecen disponibles para revisión; Firestore ya existía antes. `fixture-private.json` contiene únicamente credenciales sintéticas del emulador y debe excluirse de cualquier publicación del informe. Este directorio de evidencias no se ha publicado ni subido al repositorio.

## Continuación, 24/10/2026, desde las 07:49

Safari mostraba la navegación privada bloqueada. El intento de abrir una ventana nueva recibió: `Computer Use is not allowed to use the app com.apple.LocalAuthenticationRemoteService for safety reasons`. No se introdujo ninguna contraseña ni se superó el bloqueo. Se ha solicitado al usuario desbloquear Safari personalmente. Las nuevas pruebas de navegador no se han ejecutado todavía.

Se compiló una PWA con configuración `demo-mangalist` y se preparó un servidor de ensayo en 127.0.0.1:9526 (`pwa-server.mjs`). Puede provocar fallos de conexión únicamente para ese origen y variar un marcador del worker siguiendo el método de la suite PWA del repositorio; no corta la red del Mac ni despliega. El build existe, pero no constituye un PASS de Safari. Quasar instaló automáticamente dependencias PWA mediante pnpm; los dos archivos de soporte generados se trasladaron a evidencias. El build inicial registró `dirty:true`: no se considera artefacto de release ni reproducción exacta con lockfile npm. No hay modificación de fuentes rastreadas. Los ensayos offline de escritura y actualización siguen pendientes de desbloqueo.

## Resultados posteriores al desbloqueo — estado vigente

El usuario confirmó el desbloqueo de Safari. Se recuperó el control nativo y se ejecutaron los casos siguientes el 24/10/2026. Se mantuvieron Safari 18.6 y el candidato `6712945f9c0afa26ec6082e3b112b4fbf4c14211`. Este apartado sustituye el estado pendiente de la continuación anterior, sin borrar sus resultados históricos.

| Prueba adicional | Estado | Evidencia y límite |
|---|---|---|
| Control real del shell PWA demo | PASS | `25-pwa-control.txt`: tras recarga, controlador `http://127.0.0.1:9526/sw.js`; worker activo con marcador 1. |
| Recarga con origen local caído | PASS | Servidor configurado para destruir las conexiones de 9526; Safari recarga y sigue mostrando el login desde caché. `26-pwa-origen-caido.txt/png` y `pwa-network.jsonl`. |
| Navegación de ruta cacheada | PASS | Con ese mismo origen caído, login → recuperación muestra «Restablecer contraseña». `27-pwa-ruta-cache.txt`. No se envía correo. |
| Actualización local con dos pestañas compartidas | PASS | Se usó ventana normal sobre el origen demo nuevo, sin identidad personal. Antes: activo 1/sin waiting. Tras cambiar únicamente el marcador del worker: activo 1/waiting 2 y aviso de nueva versión. `28-pwa-update-waiting.txt/png`. |
| Formulario conservado durante espera | PASS | Primera pestaña conserva `[CUENTA-OMITIDA]` sin envío y muestra el aviso de actualización. `29-pwa-formulario-conservado.txt/png`. |
| Activación tras cerrar clientes | PASS | Con una pestaña restante: activo 1/waiting 2 (`30-pwa-una-pestana.txt`). Cerrada la última pestaña normal de ese origen y reabierto el login: activo 2, waiting false, controlled true (`31-pwa-update-activada.txt/png`). |
| Escritura pendiente offline | PASS | Favorito en obra sintética: UI Favoritos1 y mensaje explícito de cambios pendientes (`32-escritura-offline-pendiente.txt/png`). Se conservó hasta el aviso de que no se pudo confirmar en un minuto (`33-offline-plazo.png`). |
| Recuperación de escritura tras restaurar laboratorio | PASS | Se restauró el transporte SDK y los servicios locales; Reintentar terminó con confirmación de servidor, dos obras y favorito conservado (`38`, `39`). Lectura directa, únicamente del documento sintético en Firestore emulado: antes `favorite:false`, después `favorite:true`, capítulo 17 intacto (`35-server-before.json`, `37-server-after.json`). |
| Corte físico de red / app instalada sin red global | BLOCKED | Solo se simuló fallo del origen 9526 y desconexión del transporte Firestore. No se cortó Wi-Fi/Ethernet ni se acreditó arranque de la PWA instalada sin conectividad del Mac. |
| Actualización de una nueva release publicada | BLOCKED | El ensayo modifica un marcador de worker de prueba, no los assets de aplicación ni la versión publicada. No hubo deploy. |

**Alcance del ensayo PWA.** El servidor usa el mismo enfoque que `tests/pwa/updates.test.js`: añade un receptor de mensajes al worker compilado para identificar revisiones, conservando su lógica de instalación/activación. No es una nueva release de aplicación. La caché se probó mediante error de conexión de un origen local, con la conexión general del Mac disponible; `navigator.onLine` no equivale a offline físico. La PWA demo contiene clave ficticia: su inicialización produjo respuesta `API_KEY_INVALID` de Identity Toolkit. No se realizó acceso autenticado en ese build ni se escribieron datos remotos; la autenticación y escrituras se ejecutaron exclusivamente en 9516 con emuladores. Estos errores de configuración demo no se atribuyen a producción.

**Interrupción y recuperación del laboratorio.** Al retomar la escritura pendiente, solo Firestore 8188 seguía escuchando; Auth 9199, dev 9516 y servidor PWA 9526 se habían detenido. Se observaron fallos de conexión al refrescar el token emulado. No se conoce la causa de terminación de los procesos y no se atribuye a Safari. Se arrancaron Auth y dev nuevamente (`auth-continuacion.log`, `app-continuacion.log`), y se restauró exclusivamente la identidad sintética con el mismo UID mediante API administrativa del emulador (`restore-demo.mjs`, `restore-demo-result.json`). No se vació Firestore ni se crearon documentos de sustitución para simular la escritura. Tras restaurar el transporte desactivado por el ensayo y pulsar Reintentar, la escritura original llegó al servidor local. Por esta interrupción, no es una medición controlada de duración offline ni una prueba de recuperación de Auth remoto.

El botón Reintentar no se considera mecanismo para revertir por sí solo `disableNetwork(db)`: esa desconexión fue introducida por la instrumentación y se deshizo con `ml16.online()`. No se certifica reconexión automática del SDK ni ausencia global de errores de consola. El fallo de Vite ya registrado continúa abierto como incidencia del laboratorio.

**Estado conservado:** dos obras sintéticas; «ML16 Safari Demo» está en capítulo 17 y favorito. La contraseña demo no se guardó en Contraseñas de macOS (se eligió «Ahora no»). Los servicios Auth y dev se restauraron; el servidor PWA de 9526 no se reinició después de la interrupción, pues sus pruebas ya se habían ejecutado. El informe y sus evidencias siguen siendo locales, sin publicación, merge, despliegue ni cambios de Firebase remoto o bibliotecas personales.

## Ensayo físico guiado — primer intento, 16:52–16:53

Se preparó el origen demo independiente `127.0.0.1:9536` con instrumentación de eventos en el HTML cacheado (`guided-probe.js`, `guided-server.mjs`), sin campos de formulario ni credenciales en el registro. El servidor rechazaba las conexiones normales de ese origen y mantenía exclusivamente su recolector local. Antes del ensayo constaban login renderizado y controlador SW activo.

El usuario comunicó «reconectado». El registro preservado `41-corte-fisico-registro.json` muestra evento offline a las **16:52:58.065** (navigator.onLine=false, login visible, controlador activo) y online a las **16:53:38.403** (navigator.onLine=true, ruta de recuperación y encabezado «Restablecer contraseña»). La transición observada duró unos **40,3 segundos**. `42-tras-reconexion.txt/png` confirma la pantalla posterior; `43-corte-fisico-evaluacion.json` resume la comprobación.

**PASS limitado:** Safari observó transición offline→online con la página abierta. No se inventaría la interfaz de red desconectada ni ausencia de otras rutas de conectividad.

**Recarga offline: NO EJECUTADA en este intento.** No consta evento boot durante el intervalo, y al preguntarle por la recarga el usuario contestó «no lo hice». Por tanto este intento no acredita arranque/recarga desde caché bajo corte físico. Tampoco acredita de forma independiente el momento exacto de la navegación a recuperación, porque el probe inicial no registra hashchange. Se ha dejado el login preparado para repetir únicamente el paso pendiente. Las pruebas anteriores de caché con fallo de origen local conservan su alcance.

## Ensayo físico guiado — repetición confirmada, 16:55–16:56

El usuario confirma «recargue funciona». El registro automático preservado `44-recarga-fisica-registro.json` acredita:

- **16:55:27.675:** evento offline, `online:false`, controlador SW activo.
- **16:55:33.567:** arranque de página offline en `#/forgot-password`; a las **16:55:34.069** se registra el encabezado «Restablecer contraseña», todavía offline y con controlador activo.
- **16:55:50.149:** otro arranque offline en `#/login`; a las **16:55:50.650** se registra «Inicia sesión», todavía offline y con controlador activo.
- **16:56:11.246:** evento online; login renderizado y controlador activo.

**PASS: recarga del shell y rutas públicas cacheadas bajo corte físico guiado, y detección de reconexión.** Se combina la acción de desconexión confirmada por el usuario con los eventos nativos observados por la página. `45-recarga-fisica-evaluacion.json` contiene la evaluación estructurada. El servidor rechazaba además las conexiones normales del origen local; `guided-network.jsonl` registra solicitudes fallidas al worker durante el intervalo. Se restauró el servidor a modo normal tras preservar las evidencias.

Alcance: Safari real 18.6 en macOS 15.7.9, build demo instrumentado en 9536; no se introdujeron credenciales ni se enviaron formularios. El recolector de evidencias permanece en loopback y puede recibir eventos aun sin Internet. No se considera validación de bibliotecas personales, autenticación remota offline, nuevas releases publicadas ni arranque sin red de la app instalada de producción. Esos límites permanecen; no hay nuevos fallos de producto acreditados por este ensayo. Las filas BLOCKED anteriores sobre corte físico se conservan como historial, pero quedan superadas para este alcance local.

## Ampliación autorizada a OAuth y versión publicada

El usuario pidió continuar con OAuth remoto, actualización publicada y arranque offline de la app instalada de producción. Confirmó que usaría una cuenta Google demo autorizada y completó personalmente el formulario de Google. Se pulsó Google desde «MangaList ML16 Validación», se observó el paso por Firebase Auth y cuentas de Google, y tras «demo conectada» se comprobó el retorno a `https://mangalist-61bb8.web.app/#/library`, biblioteca con cero obras y confirmación del servidor. **OAuth remoto: PASS**, en la app nativa instalada y con la identidad demo declarada por el usuario. No se guardaron contraseña, códigos, tokens ni correo en evidencias; no se añadieron, importaron ni editaron obras. Evidencias: `47-oauth-demo-retorno.txt/png`.

La comprobación pública de `build-info.json` y `build-evidence.json` identifica revisión **9006459c54893de65f967439006c70c2446d05d5**, dirty false, compilada el **23/10/2026 a las 06:03:03 UTC**, modo PWA, proyecto mangalist-61bb8 (`46-public-*`). Desde Safari → Desarrollo → Inspeccionar apps y dispositivos se abrió el Web Inspector del contexto de página de la app instalada. Una lectura de Cache Storage encuentra la misma revisión en build-info cacheado; la consulta publicada coincide. El controlador está activo. `registration.update()` finaliza y se mide `active:activated`, `waiting:null`, `installing:null`. No se envió skipWaiting, no se borró caché ni se alteró el worker. Evidencia `48-prod-versiones-worker.txt/png`.

**Consulta de actualización publicada: PASS. Cambio entre releases: BLOCKED por ausencia de otra revisión disponible.** Reconsultar la misma release no acredita instalar una nueva. No se ha desplegado, revertido ni publicado una versión para crear esa condición; el ciclo local del marcador de worker conserva su propio alcance.

Para el arranque frío offline se cerró por completo la app instalada con ⌘Q, conservando la sesión demo, y se dejó Safari en el registro compañero local de 9536. `49-prod-offline-preflight.json` y `49-prod-offline-companion-before.json` recogen el punto de partida. No se declara ese caso ejecutado hasta recibir el resultado guiado. El registro compañero observa el corte del Mac, pero no instrumenta el código de producción ni prueba por sí solo el renderizado de la app instalada.

## Arranque frío offline de la app instalada de producción — resultado guiado

El usuario comunicó «app ofline abierta» y confirmó que durante el corte apareció **«Biblioteca o aviso de datos locales»**. Se mantuvo exclusivamente la cuenta demo remota autorizada, sin añadir ni editar obras.

Se observó un proceso nuevo **PID 33337**, ejecutable nativo Web App de macOS, iniciado el **24/10/2026 a las 17:11:23 Europe/Madrid**; el proceso previo de la app, PID 29752, había terminado tras el cierre con ⌘Q. El registro compañero persistido en Safari, recuperado posteriormente, contiene un intervalo offline desde **17:11:15.809** hasta **17:11:58.770**. El inicio del nuevo proceso está dentro de ese intervalo. `53-prod-offline-evaluacion.json` recoge el contraste entre tiempos y sus límites.

El recolector loopback se había detenido, por lo que su archivo inicial solo contenía un evento offline anterior, a las 17:09:10. Se preservó sin alterarlo en `51-prod-offline-server-before-recovery.json`. Se restauró el recolector y se abrió una nueva ventana normal sobre el mismo origen local: la instrumentación recuperó desde localStorage los eventos omitidos, incluidos online a las 17:10:46 y el segundo corte 17:11:15–17:11:58. Registro completo: `52-prod-offline-companion-recovered.json`. Los eventos boot posteriores de 17:14 corresponden a la recuperación del compañero local, no a la app de producción, y no se usan como prueba de su arranque.

Tras reconectar se observó directamente la ventana nativa de **MangaList ML16 Validación**, origen de producción `mangalist-61bb8.web.app/#/library`, biblioteca demo vacía y mensaje de instantánea del servidor sin cambios pendientes (`50-prod-app-tras-arranque.txt/png`). Al terminar se pulsó Cerrar sesión y se verificó el retorno al login (`54-oauth-demo-salida.txt/png`). No se borró ninguna cuenta ni biblioteca ni se revocó la sesión Google.

**PASS guiado de arranque frío offline de la app instalada y recuperación posterior.** La apertura/renderización sin red la observa y confirma el usuario; el agente acredita cierre previo, proceso nuevo dentro del corte y estado posterior a reconectar. No hubo captura automática de la ventana durante el corte. La evidencia no certifica integridad offline de una biblioteca poblada, duración prolongada, expiración de credenciales ni escrituras en producción.

Con esta ampliación quedan completados OAuth remoto demo y el arranque offline solicitado. Solo permanece sin ejecutar la transición entre dos releases públicas distintas: la revisión cacheada y publicada coincide, y `registration.update()` no encontró worker nuevo. No se despliega ni se revierte producción para fabricar esa condición.
