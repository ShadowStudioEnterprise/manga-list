# ML-16 — último caso cerrado

25/10/2026, Europe/Madrid. **PASS** del cambio entre releases públicas 0c871ab → 0bb93e7 en Safari real. OAuth remoto, arranque frío offline guiado y reconexión de la PWA instalada 0bb93e7 también completados. La captura automática offline no se obtuvo y continúa como limitación explícita.

Matriz vigente: [ESTADO-ACTUAL.md](ESTADO-ACTUAL.md). Informes: ../ML16-release-review/CIERRE-ACTUALIZACION-PUBLICA.md y CIERRE-OAUTH-OFFLINE-INSTALADA.md. La preparación y los bloqueos históricos se conservan en ULTIMO-CASO-PENDIENTE-HISTORICO-PRE-CONSOLIDACION.md. No requiere otra publicación para cerrar este ensayo.
