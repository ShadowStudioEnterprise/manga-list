# ML-16: corte físico guiado

Preparado el 24/10/2026 a las 16:50 Europe/Madrid en Safari nativo 18.6/macOS 15.7.9.

Pestaña preparada: http://127.0.0.1:9536/#/login. No usa cuenta personal. El login ya se ha renderizado con service worker controlando la página. El servidor rechaza deliberadamente las conexiones normales al origen, pero conserva un recolector de evidencias solo en loopback.

1. Mantén abierta esa pestaña de Safari y los servicios locales. No inicies sesión.
2. Desconecta Wi-Fi y cualquier otra conexión a Internet activa (Ethernet o conexión compartida). No cambies ajustes de seguridad.
3. En la pestaña de puerto **9536**, pulsa **⌘R**. Comprueba si aparece **Inicia sesión**.
4. Pulsa **¿Has olvidado la contraseña?** y comprueba si aparece **Restablecer contraseña**. No envíes el formulario.
5. Vuelve a conectar la red. Espera unos segundos y responde en el chat: **reconectado**, indicando si ambos textos se mostraron o qué error viste.

El registro automático guarda hora, estado online de Safari, controlador SW, ruta y encabezado. No registra campos, credenciales ni bibliotecas. Usa almacenamiento del origen demo y un archivo local `guided-offline-events.json`. El corte físico lo realiza el usuario; el resultado se evaluará combinando su confirmación con el registro. `navigator.onLine=false` por sí solo no acredita todos los tipos de corte de red.

El ensayo se refiere al build demo local instrumentado, no al backend remoto ni al arranque offline de la app instalada de producción. No se desplegará una nueva versión para probar actualizaciones.
